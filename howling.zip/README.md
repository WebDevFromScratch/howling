# Howling

A [Ghost](http://github.com/tryghost/ghost/) theme, made with
[Tailwind CSS](https://github.com/tailwindcss/tailwindcss).

# Todos

- [x] build post view
- [x] add menu/navbar
- [x] extract footer properly - well, somewhat properly so far...
- [ ] add author pages
- [ ] add custom pages
- [ ] add better readme
- [ ] add easy customisation possibilities
- [ ] add different treating of posts without data like: image, tags, etc.
- [ ] add different treating of collaborative posts

# Development

To build assets, simply run `gulp` command

# Using on your website
